<?php
namespace dynoser\autoload;

define('ROOT_DIR', __DIR__);

require_once 'autoload.php';

AutoLoader::$classesArr['dynoser/walkdir'] = ':https://raw.githubusercontent.com/dynoser/WalkDir/main/src/walkdir.hashsig.zip *' . __DIR__ . '/tmp/ WalkDir.php';
AutoLoader::$classesArr['dynoser/keysigner'] = ':https://raw.githubusercontent.com/dynoser/keysigner/main/src/keysigner.hashsig *' . __DIR__ . '/tmp/keysigner/ KeySigner.php';

//AutoLoader::$classesArr['dynoser\walkdir\WalkDir'] = ':https://raw.githubusercontent.com/dynoser/WalkDir/main/src/walkdir.hashsig.zip @/dynoser/walkdir/src/ WalkDir.php';

$n = new \dynoser\keysigner\KeyEd25519PPK();
$n = new \dynoser\keysigner\KeySigner();
$n = new \dynoser\walkdir\WalkDir();
